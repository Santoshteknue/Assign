#include<iostream>
using namespace std;

void sqrtprint(int n, int number[], int adjsq[]) {
	for (int i = 0;i < n;i++) {
		cout << number[i] << " " << adjsq[i];
	}
}

void checkcoordinate(int n,int number[],int xcor1[100],int ycor1[100], int xcor2[100], int ycor2[100], int xcor3[100], int ycor3[100], int xcor4[100], int ycor4[100]) {
	int count = 0;
	int adj[100];
		for (int k = 0;k < n; k++) {
		for (int j = 0;j < n;j++) {
			if (xcor1[k] == xcor2[j] && ycor1[k] == ycor2[j] && xcor4[k] == xcor3[j] && ycor4[k] == ycor3[j]) {
				count++;
			}
			if (xcor2[k] == xcor1[j] && ycor2[k] == ycor1[j] && xcor3[k] == xcor4[j] && ycor3[k] == ycor4[j]) {
				count++;
			}
			if (xcor4[k] == xcor1[j] && ycor4[k] == ycor1[j] && xcor3[k] == xcor2[j] && ycor3[k] == ycor2[j]) {
				count++;
			}
			if (xcor1[k] == xcor4[j] && ycor1[k] == ycor4[j] && xcor2[k] == xcor3[j] && ycor2[k] == ycor3[j]) {
				count++;
			}
		}
		
		adj[k] = count;
		count = 0;
	}
	for (int i = 0;i < n;i++) {
		cout << number[i] << " " << adj[i] << endl;
	}

}

int main() {
	int n;
	int number[20];
	int xcor1[100],  ycor1[100];
	int xcor2[100],  ycor2[100];
	int xcor3[100],  ycor3[100];
	int xcor4[100],  ycor4[100];

	cout << "enter the no of squares" << endl;
	cin >> n;
	for (int i = 0;i < n;i++) {
		cin >> xcor1[i] >> ycor1[i] >> xcor2[i] >> ycor2[i] >> xcor3[i] >> ycor3[i] >> xcor4[i] >> ycor4[i];
		number[i] = i + 1;
	}
	checkcoordinate(n, number, xcor1, ycor1, xcor2, ycor2, xcor3, ycor3, xcor4, ycor4);
}