/********************************Input Specification***********************************************************
The first line will be an integer N, indicating the number of words that will follow. Assume
N will never be greater than twenty (20).The next N lines of input will contain words, which are to 
be chained. Assume that the maximum length of a word will never exceed thirty (30) characters.
*********************************Output Specification**********************************************************
Your program should output the chain of words, one word on a separate line. If there is
no chain possible from the given words, the program should print IMPOSSIBLE*/
#include<iostream>
using namespace std;
class Chain{
	public:
		string savetrail(string temp){
			int lastletter = temp.length();
			char tomatch[3] = {temp[lastletter],temp[(lastletter-1)],temp[(lastletter-2)]};
			return tomatch;
		}
		string savetrailX(string tempX){
			int lastletterX = tempX.length();
			char tomatchX[4] = {tempX[lastletterX],tempX[(lastletterX-1)],tempX[(lastletterX-2)],tempX[(lastletterX-3)]};
			return tomatchX;
		}
};
int main(){
	Chain obj;
	int numberOfWords,flag=0,flag2=0;
	string words[20];
	cin>>numberOfWords;
	for(int i=0; i<numberOfWords; i++){
		cin>>words[i];
	}
	string match = obj.savetrail(words[0]);
		for(int k=0; k<numberOfWords-1; k++){
				string temp1 = obj.savetrail(words[k+1]);
				if(match[0] == temp1[0]&& match[1] == temp1[1]&& match[2] == temp1[2]){
					
					match = obj.savetrail(words[k+1]);
					flag = 1;
				}
				}
		string matchX = obj.savetrailX(words[0]);
		for(int kX=0; kX<numberOfWords-1; kX++){
				string temp1X = obj.savetrailX(words[kX+1]);
				if(matchX[0] == temp1X[0]&& matchX[1] == temp1X[1]&& matchX[2] == temp1X[2]&& matchX[3] == temp1X[3]){
					
					matchX = obj.savetrailX(words[kX+1]);
					flag = 9;
				}
				if(flag==1 || flag==9){
					if(flag2==0){
						cout<<words[1-1]<<endl;
						flag2=1;
					}
					cout<<words[kX+1]<<endl;
				}
		}
		if(flag2==0)
			cout<<"IMPOSSIBLE"<<endl;
	return 0;
}
