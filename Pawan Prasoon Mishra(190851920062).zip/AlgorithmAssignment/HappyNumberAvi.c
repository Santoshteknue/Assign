#include <stdio.h>  

int isHappyNumber(int num){  
    int rem = 0, sum = 0;    
   
    while(num > 0){  
        rem = num%10;  
        sum = sum + (rem*rem);  
        num = num/10; 
    }  
    return sum;  
}  
      
int main()  
{  
    int a,b,flag,result,i;
    int count;
    printf("Enter 1st Number: ");
    scanf("%d",&a);
    do{
	    printf("\nEnter 2nd Number (greater than %d): ",a);
    	scanf("%d",&b);
    	flag=0;
    	if(a>b){
    		printf("\nPlease Enter Greater Than %d",a);	
			flag=1;
	    }
	}while(flag!=0);
	
    printf("\nList of happy numbers between %d and %d: \n",a,b);  
    for(i = a; i <= b; i++){  
        result = i;  
        count = 1;  
        //Happy number always ends with 1 and   
        //unhappy number ends in a cycle of repeating numbers which contains 4  
        while(result != 1 && result != 4){  
            result = isHappyNumber(result); 
			count ++; 
        }  
          
        if(result == 1)  
            printf("%d is %d times\n", i,count);  
    }  
   
    return 0;  
}
