//SimpleFile.js
testFunc = function() {
	console.log("testFunc");
}

addFunc = function (first, second) {
	return first + second;
}

print = function(msg){
	console.log(msg);
}

/*var res = addFunc(123,234);
print(res);*/