<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="content.php" method="POST">
		Enter the Date:
		<input type="date" name="dt" placeholder="Enter Date">
		<button type="submit">Accept</button>
	</form>
<!-- <?php 
	$dt = date("d-M-y");
	echo $dt;

 ?> -->
 <hr/>
 &nbsp;Phaniraj Training <?php echo date("Y") ?>
</body>
</html>