<!DOCTYPE html>
<html>
<head>
	<title>Board Main Page</title>
</head>
<body>
	<h1>SSC Board App</h1>
	<nav>
		<ul type="none">
			<li><a href="studentReg.php">Student Registration</a></li>
			<li><a href="marks_entry.php">Marks Entry</a></li>
		</ul>
	</nav>
	<hr/>
	<p>&copy; SSC Board 2019</p>
</body>
</html>